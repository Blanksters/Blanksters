package sanity;

import extensions.UIActions;
import extensions.Verifications;
import io.qameta.allure.Description;
import org.testng.annotations.Test;
import utilities.CommonOps;
import workflows.ElectronFlows;

import javax.swing.plaf.synth.ColorType;

public class todoListElectron extends CommonOps {

    @Test(description = "Test 01 - Add and Verify New Task")
    @Description("This Test add new task and check list")
    public void Test01_addTaskAndCheckList(int actual, int expected){
        ElectronFlows.add_new_task("LearnToRun");
        ElectronFlows.add_new_task("FasterStep");
        Verifications.VerifyText(ElectronFlows.numberOfTasks(), 2);
    }

    @Test(description = "Test 02 - Chose Color")
    @Description("This Test add new Color To task")
    public void Test01_addTaskAndCheckList(String actual, String Expected){
        ElectronFlows.ColorType(todoMain.red_color.getText());
    }





}
