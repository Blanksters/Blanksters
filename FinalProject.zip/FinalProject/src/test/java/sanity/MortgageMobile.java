package sanity;

import extensions.Verifications;
import io.qameta.allure.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilities.CommonOps;
import workflows.MobileFlows;

@Listeners(utilities.Listeners.class)
public class MortgageMobile extends CommonOps {

    @Test(description = "Test01 - Verify Mortgage")
    @Description("This Test Fill and calculate repayment")
    public void test01_VerifyMortgage(){
        MobileFlows.calcualtorMort("2000", "6", "2");
        Verifications.verifyTextInElement(mortgageMain.txt_Repayment, "£"+"29.75");
    }

    @Test(description = "Test02 - Verify Mortgage 500k for 10 Years")
    @Description("This Test Fill and calculate repayment for 10 Years")
    public void test02_VerifyMortgage(){
        MobileFlows.calcualtorMort("500000", "10", "4");
        Verifications.verifyTextInElement(mortgageMain.txt_Repayment, "£"+"5137.12");
    }

    @Test(description = "Test02 - Verify Mortgage 11 for 2 Years")
    @Description("This Test Fill and calculate repayment for 2 Years")
    public void test03_VerifyMortgage(){
        MobileFlows.calcualtorMort("1" + "1", "2", "4");
        Verifications.verifyTextInElement(mortgageMain.txt_Repayment, "£"+".49");
    }
}

