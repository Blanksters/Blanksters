package sanity;

import extensions.UIActions;
import extensions.Verifications;
import io.qameta.allure.Description;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utilities.CommonOps;
import workflows.WebFlows;

@Listeners(utilities.Listeners.class)
public class Bitrix24Web extends CommonOps{

    @Test(description = "Test01 - Verify Start")
    @Description("This Test verifies Login and the Main Start")
    public void test01_verifyStart(){
        WebFlows.login("aqatestercase@gmail.com", "Loliko77");
        Verifications.verifyTextInElement(BitrixPageStart.head_title, "Bitrix");
    }

    @Test(description = "Test02 - Verify Open Left Menu")
    @Description("This Test verifies number of row elements at collbaration")
    public void test02_OpenLeftMenu(){
        WebFlows.openLeftMenu();
        Verifications.numberOfElements(BitrixLeftMenu.allbtnrows, 8);
    }

    @Test(description = "Test03 - Verify Like Button")
    @Description("This Test verifies The like/unlike button working")
    public void test03_SubmitLike(){
        WebFlows.LikeBtn();
        Verifications.verifyTextInElement(BitrixLike.like_approve, "You");
    }

    @Test(description = "Test04 - Verify Message Text ")
    @Description("This Test verifies send message and deleted")
    public void test04_SendMassage(){
        WebFlows.closeLikeBtn();
        WebFlows.SendMassage("Hello Yoni");
        Verifications.verifyTextInElement(BitrixSendMessaage.check_text, "Hello Yoni");
    }

    @Test(description = "Test05 - Verify Invitation Elements Exists ")
    @Description("This Test verifies the visability of invintation list options (using soft assertion)")
    public void test05_VerifyInvationOptions(){
        WebFlows.GoToInviteUser();
        Verifications.visibilityOfElements(BitrixSendMessaage.list_Invitation_optinos);{
        }
    }

    @Test(description = "Test06 - Verify Add User Invite exist")
    @Description("This Test verifies number of heads user added")
    public void test06_AddNewUser(){
        WebFlows.addNewUser("Work", "Hard", "workharder@gmail.com", "AQA");
   //     WebFlows.closeAddUser();
        Verifications.numberOfElements(BitrixInviteUser.check_NumberOfUsers, 2);
//        WebFlows.searchUserExists("Work Hard");
//        Verifications.verifyTextElement(BitrixInviteUser.txt_search, "Work Hard");
    }

    @Test(description = "Test07 - Verify Deletion the added user invite")
    @Description("This Test verifies the number of heads after user deleted")
    public void test07_DeleteNewInvation(){
        WebFlows.deleteInvitedUser();
        Verifications.numberOfElements(BitrixInviteUser.check_NumberOfUsers, 2);
    }

    @Test(description = "Test08 - Verify Logo Image")
    @Description("This Test verifies Logo Image Using Sikuli tool")
    public void test08_VerifyheadLogo() {
        Verifications.visualElement("24main");
    }

    @Test(description = "Test09 - Search Users", dataProvider = "data-provider-users", dataProviderClass = utilities.ManageDDT.class)
    @Description("This Test Searched Users in table using DDT")
    public void test09_SearchUsers(String user, String shouldExist) {
        WebFlows.searchAndVerifyUsers(user, shouldExist);
    }
}


