package sanity;

import extensions.Verifications;
import io.qameta.allure.Description;
import org.testng.annotations.Test;
import utilities.CommonOps;
import workflows.ApiFlows;

public class GrafanaAPI extends CommonOps {

    @Test(description = "Test 01: Get Team From Grafana API")
    @Description("This Test Verify Team Property")
    public void test_01_verifyTeam() {
        Verifications.VerifyText(ApiFlows.getTeamProperty("teams[0].name"), "archi");
    }

    @Test(description = "Test 02: Add a Team and Verify")
    @Description("This Test Add And Verify New Team")
    public void test_02_addTeamAndVerifyTeam() {
        ApiFlows.postTeam("rec", "recc@das.com");
        Verifications.VerifyText(ApiFlows.getTeamProperty("teams[1].name"), "rec");
    }

    @Test(description = "Test 03: Update Team and Verify")
    @Description("This Test Update and Verify Team")
    public void test_03_addTeamAndVerifyTeam() {
        String id = ApiFlows.getTeamProperty("teams[1].id");
        ApiFlows.updateTeam("rec", "recc@das.com", id);
        Verifications.VerifyText(ApiFlows.getTeamProperty("teams[1].email"), "recc@das.com");
    }

    @Test(description = "Test 04: Delete Team and Verify")
    @Description("This Test Delete and Verify Team")
    public void test_04_deleteTeamAndVerifyTeam() {
        Verifications.VerifyText(ApiFlows.getTeamProperty("totalCount"), "2");
        String id = ApiFlows.getTeamProperty("teams[1].id");
        ApiFlows.deleteTeam(id);
        Verifications.VerifyText(ApiFlows.getTeamProperty("totalCount"), "1");
    }

    @Test(description = "Test 05: Get Member From Grafana API")
    @Description("This Test Verify Member Exist")
    public void test_05_verifyMemberExist() {
        Verifications.VerifyText(ApiFlows.getMemberExist("name"), "daa");
    }

    @Test(description = "Test 06: Get Users From Grafana API")
    @Description("This Test Verify Users Property")
    public void test_06_verifyUsers() {
        Verifications.VerifyText(ApiFlows.getUsersProperty("users.id"), "[]");
    }
}
