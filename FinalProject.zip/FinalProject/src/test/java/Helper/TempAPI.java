package Helper;

import com.google.gson.JsonObject;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

public class TempAPI {
    RequestSpecification httpRequest;
    Response response;
    String url = "http://localhost:3000/";

    @Test
    public void testAPI() {
    RestAssured.baseURI = url;
    httpRequest = new RestAssured().given().auth().preemptive().basic("admin", "admin");

    //Get Request
    response = httpRequest.get("/api/teams/search");
    response.prettyPrint();

    // Request
//        JSONObject params = new JSONObject();
  //      params.put("name", "loliko1Team");
  //      params.put("email", "loliko77@gmail.com");

  //            httpRequest.header("Content-Type", "application/json");
 //       httpRequest.body(params.toJSONString());
  //      response = httpRequest.put("/api/teams");

//       response.prettyPrint();

//        params.put("email","rocknroll@gmail.com");
//        params.put("name","Roll");
//        params.put("login","Rock");
//        params.put("theme", "light");
//        httpRequest.header("Content-Type","application/json");
//        httpRequest.body(params.toJSONString());
//        response = httpRequest.put("/api/users/2");
//        response.prettyPrint();
    }
}
