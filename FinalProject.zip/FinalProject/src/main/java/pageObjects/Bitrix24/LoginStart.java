package pageObjects.Bitrix24;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginStart {

        @FindBy(how = How.ID, using = "login")
        public WebElement txt_username;

        @FindBy (how = How.CSS, using = "button[data-action='submit']")
        public WebElement btn_next1;

        @FindBy(how = How.XPATH, using = "//input[@type='password']")
        public WebElement txt_password;

        @FindBy(how = How.XPATH, using = "//*[contains(@class,'ui-btn-success')]")
        public WebElement btn_next2;

        @FindBy(how = How.XPATH, using = "//a[text()='Go']")
        public WebElement btn_go;

    }