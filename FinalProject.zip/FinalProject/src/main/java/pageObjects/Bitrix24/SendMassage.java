package pageObjects.Bitrix24;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import java.util.List;

public class SendMassage {

    @FindBy (how = How.CSS, using = "body[contenteditable='true']")
    public WebElement btn_to_txt;

    @FindBy (how = How.CSS, using = "button[id='blog-submit-button-save']")
    public WebElement btn_saveAndSend;

    @FindBy (how = How.CSS, using = "div[id='microoPostFormLHE_blogPostForm_inner']")
    public WebElement tryToClick;

    @FindBy (how = How.CSS, using = "div[class='feed-post-text']")
    public WebElement check_text;

    @FindBy (how = How.CSS, using = "div[class='feed-post-right-top-menu']")
    public WebElement go_toDel;

    @FindBy (how = How.XPATH, using = "//span[text()='Delete']")
    public WebElement btn_Del;

    @FindBy (how = How.XPATH, using = "//span[text()='The post has been deleted.']")
    public WebElement txt_postDeleted;

    @FindBy (how = How.XPATH, using = "//ul[@id='sidepanelMenu']/li")
    public List<WebElement> list_Invitation_optinos;

}
