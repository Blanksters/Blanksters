package pageObjects.Bitrix24;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CancelInvitation {

    @FindBy(how = How.XPATH, using = "//button[text()='Invite']")
    public WebElement btn_invite_TO_Close;

    @FindBy (how = How.XPATH, using = "//span[text()='Cancel invitation']")
    public WebElement btn_DelNewUser;

    @FindBy (how = How.CSS, using = "span[class='popup-window-button popup-window-button-accept']")
    public WebElement accept_Del;

    @FindBy (how = How.XPATH, using = "//*[@id='bx-im-external-recent-list']/span[1]/span[2]/span[1]")
    public WebElement User_right_Btn1;

}
