package pageObjects.Bitrix24;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MainPage {
    @FindBy(how = How.CSS, using = "span[class='logo-text']")
    public WebElement head_title;

    @FindBy(how = How.CSS, using = "span[id='pagetitle']")
    public WebElement Head_menu;


}
