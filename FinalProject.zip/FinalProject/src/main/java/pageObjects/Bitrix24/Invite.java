package pageObjects.Bitrix24;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import java.util.List;

public class Invite {

    @FindBy (how = How.CSS, using = "button[class='ui-btn ui-btn-round license-btn license-btn-primary']")
    public WebElement btn_invite;

    @FindBy (how = How.CSS, using = "a[data-role='invitationPopupButton']")
    public WebElement btn_addinvite;

    @FindBy (how = How.XPATH, using = "//*[@id='sidepanelMenu']/li[5]/a/div")
    public WebElement btn_addUser;

    @FindBy (how = How.CSS, using = "div[class='invite-send-success-text']")
    public WebElement check_invitation;

    @FindBy (how = How.CSS, using = "input[name='ADD_NAME']")
    public WebElement add_firstName_txt;

    @FindBy (how = How.CSS, using = "input[name='ADD_LAST_NAME']")
    public WebElement add_lastName_txt;

    @FindBy (how = How.CSS, using = "input[name='ADD_EMAIL']")
    public WebElement add_email_txt;

    @FindBy (how = How.CSS, using = "input[name='ADD_POSITION']")
    public WebElement add_position_txt;

    @FindBy (how = How.CSS, using = "button[name='save']")
    public WebElement btn_finalSave;

    @FindBy (how = How.CSS, using = "a[id='ui-button-panel-close']")
    public WebElement btn_Close_DownInvite;

    @FindBy (how = How.CSS, using = "div[class='pagetitle']")
    public WebElement ClickFEED_TO_CloseInvite;

    @FindBy (how = How.XPATH, using = "//span[@data-avatar='/bitrix/js/im/images/blank.gif']")
    public List<WebElement> check_NumberOfUsers;

    @FindBy (how = How.CSS, using = "input[class='header-search-input']")
    public WebElement txt_searchs;

    @FindBy (how = How.CSS, using = "div[bx-search-block-id='users']")
    public List<WebElement> check_If_Available_User;

    @FindBy (how = How.XPATH, using = "//span[text()='Employees']")
    public WebElement btn_employes;

    @FindBy (how = How.XPATH, using = "//span[text()='Company']")
    public WebElement btn_hover_company;

    @FindBy (how = How.CSS, using = "div[id='workarea-content']")
    public List<WebElement> list_of_users;

}
