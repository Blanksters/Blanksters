package pageObjects.Bitrix24;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import java.util.List;

public class LeftMenu {

    @FindBy(how = How.XPATH, using = "//*[@id='bx_left_menu_menu_teamwork']/a/span[1]")
    public WebElement btn_collaboration;

    @FindBy (how = How.XPATH, using = "//li[@id='bx_left_menu_menu_live_feed']/a/span[2]")
    public WebElement btn_feed;

    @FindBy (how = How.XPATH, using = "//div[@class='feed-post-informers-cont']/span")
    public List<WebElement> allbtnrows;

//    @FindBy (how = How.CSS, using = "div[class='feed-post-text-more-but']")
//    public WebElement see_more;

    @FindBy (how = How.CSS, using = "div[id='LIVEFEED_FILTER_TOOLBAR']")
    public WebElement move_from_leftSide;

}