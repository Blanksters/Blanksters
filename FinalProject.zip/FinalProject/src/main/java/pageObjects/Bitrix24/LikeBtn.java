package pageObjects.Bitrix24;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LikeBtn {

    @FindBy (how = How.XPATH, using = "//a[text()='Like']")
    public WebElement btn_like;

    @FindBy (how = How.XPATH, using = "//div[contains(@id,'bx-ilike-top-users')]")
    public WebElement like_approve;

}
