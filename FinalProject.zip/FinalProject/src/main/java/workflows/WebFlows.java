package workflows;

import extensions.UIActions;
import extensions.Verifications;
import io.qameta.allure.Step;
import org.openqa.selenium.support.ui.ExpectedConditions;
import utilities.CommonOps;

public class WebFlows extends CommonOps {
    @Step("Business Flow: Login")
    public static void login(String user, String pass){
        UIActions.updateText(BitrixLogin.txt_username, user);
        UIActions.clickable(BitrixLogin.btn_next1);
        UIActions.updateText(BitrixLogin.txt_password, pass);
        UIActions.clickable(BitrixLogin.btn_next2);
        UIActions.clickvisabale(BitrixLogin.btn_go);
    }

    @Step("Business Flow: Open Left Menu")
    public static void openLeftMenu(){
        UIActions.mouseHoverDoubleClick(BitrixLeftMenu.btn_collaboration, BitrixLeftMenu.btn_feed);
        wait.until(ExpectedConditions.visibilityOf(UIActions.BitrixLeftMenu.btn_collaboration));
        UIActions.mouseHoverOneClick(BitrixLeftMenu.btn_collaboration);
        UIActions.mouseHover(BitrixLeftMenu.move_from_leftSide);
    }

    @Step("Business Flow: Like Button Open")
    public static void LikeBtn(){
        UIActions.mouseHoverOneClick(BitrixLike.btn_like);
        UIActions.geText(BitrixLike.like_approve);
    }

    @Step("Business Flow: Like Button Close")
    public static void closeLikeBtn(){
        UIActions.mouseHoverOneClick(BitrixLike.btn_like);
    }

    @Step("Business Flow: Send And Delete Message")
    public static void SendMassage(String text){
        UIActions.justclick(BitrixSendMessaage.tryToClick);
        UIActions.switch_Frames();
        UIActions.updateText(BitrixSendMessaage.btn_to_txt, text);
        UIActions.moveOut_iFrame();
        UIActions.justclick(BitrixSendMessaage.btn_saveAndSend);
        UIActions.justclick(BitrixSendMessaage.go_toDel);
        UIActions.justclick(BitrixSendMessaage.btn_Del);
        UIActions.acceptAlert();
    }

    @Step("Business Flow: Invite Page")
    public static void GoToInviteUser(){
        UIActions.justclick(BitrixInviteUser.btn_invite);
        UIActions.justclick(BitrixInviteUser.btn_addinvite);
        UIActions.switch_Frame1();
    }

    @Step("Business Flow: Add Invited New User")
    public static void addNewUser(String name, String lastname, String email, String position) {
        UIActions.clickable(BitrixInviteUser.btn_addUser);
        UIActions.updateText(BitrixInviteUser.add_firstName_txt, name);
        UIActions.updateText(BitrixInviteUser.add_lastName_txt, lastname);
        UIActions.updateText(BitrixInviteUser.add_email_txt, email);
        UIActions.updateText(BitrixInviteUser.add_position_txt, position);
        UIActions.clickable(BitrixInviteUser.btn_finalSave);
        UIActions.clickable(BitrixInviteUser.btn_Close_DownInvite);
        UIActions.moveOut_iFrame();
        UIActions.justclick(BitrixCancelInv.btn_invite_TO_Close);
    }


    @Step("Business Flow: Delete Invited New User")
    public static void deleteInvitedUser(){
        UIActions.mouseHoverOneClick(BitrixInviteUser.ClickFEED_TO_CloseInvite);
        UIActions.rightclick(BitrixCancelInv.User_right_Btn1);
        UIActions.mouseHoverOneClick(BitrixCancelInv.btn_DelNewUser);
        UIActions.mouseHoverOneClick(BitrixCancelInv.accept_Del);
    }

    @Step("Business Flow: Search And Verfiy Users")
    public static void searchAndVerifyUsers(String user, String shouldExists) {
        UIActions.updateTextHuman(BitrixInviteUser.txt_searchs, user);
        if (shouldExists.equalsIgnoreCase("exist"))
            Verifications.existanceOfElement(BitrixInviteUser.check_If_Available_User);
        else if (shouldExists.equalsIgnoreCase("not-exists"))
            Verifications.nonExistanceOfElement(BitrixInviteUser.check_If_Available_User);
        else
            throw new RuntimeException("Invailid Expected Output in Data Driven testing Should be exist or not-exists");
    }

    @Step("Business Flow: Check users Exist")
    public static void searchUsersExistInCompany(){
        UIActions.mouseHoverDoubleClick(BitrixInviteUser.btn_hover_company, BitrixInviteUser.btn_employes);
        UIActions.geText(BitrixInviteUser.list_of_users.get(10));
    }
}
