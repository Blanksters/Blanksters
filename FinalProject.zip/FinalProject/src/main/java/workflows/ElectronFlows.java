package workflows;

import extensions.UIActions;
import io.qameta.allure.Step;
import org.openqa.selenium.Keys;
import org.python.antlr.ast.Str;
import utilities.CommonOps;

public class ElectronFlows extends CommonOps {

    @Step("Add New Task")
    public static void add_new_task(String taskname){
        UIActions.updateText(todoMain.txt_create, taskname);
        UIActions.insertKey(todoMain.txt_create, Keys.RETURN);
    }

    @Step("Count and Return Number of Tasks in List")
    public static int numberOfTasks() {
        return todoMain.list_tasks.size();
    }

    @Step("Check Color and Return")
    public static void ColorType(String taskname){
        UIActions.mouseHoverDoubleClick(todoMain.choose_color, todoMain.red_color);
        UIActions.updateText(todoMain.txt_create, taskname);
        UIActions.insertKey(todoMain.txt_create, Keys.RETURN);
    }


}
