package workflows;

import extensions.MobileActions;
import io.qameta.allure.Step;
import utilities.CommonOps;

public class MobileFlows extends CommonOps {

    @Step("Business Flow: Start Calculate Mortgage")
    public static void calcualtorMort(String amount, String years, String rate) {
        MobileActions.updateText(mortgageMain.txt_Amount, amount);
        MobileActions.updateText(mortgageMain.txt_Years, years);
        MobileActions.updateText(mortgageMain.txt_Rate, rate);
        MobileActions.tap(mortgageMain.btn_Calculate);
    }
}
