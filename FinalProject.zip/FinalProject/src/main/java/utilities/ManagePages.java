package utilities;

import org.openqa.selenium.support.PageFactory;
import pageObjects.Bitrix24.*;

public class ManagePages extends Base{

    public static void initBitrix() {
        BitrixLogin = PageFactory.initElements(driver, LoginStart.class);
        BitrixLeftMenu = PageFactory.initElements(driver, LeftMenu.class);
        BitrixPageStart = PageFactory.initElements(driver, MainPage.class);
        BitrixSendMessaage = PageFactory.initElements(driver, SendMassage.class);
        BitrixLike = PageFactory.initElements(driver, LikeBtn.class);
        BitrixInviteUser = PageFactory.initElements(driver, Invite.class);
        BitrixCancelInv = PageFactory.initElements(driver, CancelInvitation.class);
    }

    public static void initMortgage() {
        mortgageMain = new pageObjects.Mortgage.MainPage(mobileDriver);
    }

    public static void initTodo() {
        todoMain = PageFactory.initElements(driver, pageObjects.todo.MainPage.class);
    }
}
