package extensions;

import io.qameta.allure.Step;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.sikuli.script.FindFailed;
import utilities.CommonOps;
import java.util.List;

import static org.testng.AssertJUnit.*;


public class Verifications extends CommonOps {

    @Step("Verify Text Element")
    public static void verifyTextInElement(WebElement elem, String expected) {
        UIActions.wait.until(ExpectedConditions.visibilityOf(elem));
        assertEquals(elem.getText(), expected);
    }

    @Step("Verify Number Of Elements")
    public static void numberOfElements(List<WebElement> elems, int expected) {
        UIActions.wait.until(ExpectedConditions.visibilityOf(elems.get(elems.size()-1)));
        assertEquals(elems.size(), expected);
    }

    @Step("Verify Visibility Of Elements (SoftAssertion")
    public static void visibilityOfElements(List<WebElement> elems) {
        for (WebElement elem : elems){
            softAssert.assertTrue(elem.isDisplayed(), "Nope.." + elem.getText() + " Element Is not Displayed");
        }
        softAssert.assertAll("Some Elements is not displayed");
    }

    @Step("Verify Element Visually")
    public static void visualElement(String expectedImageName) {
        try {
            screen.find(getData("ImageRepo") + expectedImageName +".png");
        } catch (FindFailed findFailed) {
            System.out.println("Error Comparing Image File: " + findFailed);
            fail("Error comparing Image File: " + findFailed);
        }
    }

    @Step("Verify Element Display")
    public static void existanceOfElement(List<WebElement> elements) {
        assertTrue(elements.size() > 0);
    }

    @Step("Verify Element Not Display")
    public static void nonExistanceOfElement(List<WebElement> elements) {
        assertTrue(elements.size() > 0);
    }

    @Step("Verify Elements Of Users")
    public static void ExistanceOfElementsOfUsers(List<WebElement> elements, int expectedNumber) {
        assertTrue(elements.size() == expectedNumber);
    }
    @Step("Verify Elements Is working")
    public static void nonExistanceOfElementOfUsers(List<WebElement> elements, int expectedNumber) {
        assertTrue(elements.size() == expectedNumber);
    }

    @Step("Verify Text Equals to Text")
    public static void VerifyText(String actual, String expected) {
        assertEquals(actual, expected);
    }

    @Step("Verify Number Equals to Number")
    public static void VerifyText(int actual, int expected) {
        assertEquals(actual, expected);
    }

}
