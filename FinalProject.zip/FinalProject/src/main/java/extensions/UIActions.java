package extensions;

import com.google.common.util.concurrent.Uninterruptibles;
import io.qameta.allure.Step;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import utilities.CommonOps;

import java.security.Key;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class UIActions extends CommonOps{

    public static void checkDisplayedClick(WebElement elem1){
        wait.until(ExpectedConditions.visibilityOf(elem1));
        action.pause(3).contextClick(elem1).build().perform();
    }

    @Step("Click on Element")
    public static void justclick(WebElement elem){
      //  elem.click();
        action.click(elem).build().perform();
    }

    @Step("Check If Element Clickable and Click")
    public static void clickable(WebElement elem){
        wait.until(ExpectedConditions.elementToBeClickable(elem));
        elem.click();
    }

    @Step("Check If Element Visable and Click")
    public static void clickvisabale(WebElement elem){
        wait.until(ExpectedConditions.visibilityOf(elem));
        elem.click();
    }

    @Step("Update Text Element as Human")
    public static void updateTextHuman(WebElement elem, String text){
        wait.until(ExpectedConditions.visibilityOf(elem));
        for (char ch : text.toCharArray()) {
            Uninterruptibles.sleepUninterruptibly(500, TimeUnit.MILLISECONDS);
            elem.sendKeys(ch + "");
        }
    }

    @Step("Update Text Element")
    public static void updateText(WebElement elem, String text){
        wait.until(ExpectedConditions.visibilityOf(elem));
        elem.sendKeys(text);
    }

    @Step("Get The Text Of Element")
    public static void geText(WebElement elem){
        wait.until(ExpectedConditions.visibilityOf(elem));
        elem.getText();
    }

    @Step("Clear Choosen Element")
    public static void updateClear(WebElement elem){
        wait.until(ExpectedConditions.visibilityOf(elem));
        elem.clear();
    }

    @Step("Updated DropDown Element")
    public static void updateDropDown (WebElement elem, String text){
        wait.until(ExpectedConditions.visibilityOf(elem));
        Select dropDown = new Select(elem);
        dropDown.selectByVisibleText(text);
    }

    @Step("MouseHover - Click and Pause - 2 Elements and Elements Visability Check")
    public static void mouseHoverDoubleClick(WebElement elem1, WebElement elem2){
        action.moveToElement(elem1).click().pause(Duration.ofSeconds(2)).moveToElement(elem2).click().build().perform();
    }

    @Step("MouseHover - Click and Pause - One Element and Visability Check")
    public static void mouseHoverOneClick(WebElement elem1){
        wait.until(ExpectedConditions.visibilityOf(elem1));
        action.moveToElement(elem1).pause(Duration.ofSeconds(2)).click().build().perform();
    }

    @Step("MouseHover - Click - Element and Visability Check")
    public static void mouseHover(WebElement elem1){
        wait.until(ExpectedConditions.visibilityOf(elem1));
        action.moveToElement(elem1).click();
    }

    @Step("Switch - Accept PopUp")
    public static void acceptAlert(){
        Alert popup = driver.switchTo().alert();
        popup.accept();
    }

    @Step("Switch - dicline PopUp")
    public static void diclineAlert(){
        Alert popup = driver.switchTo().alert();
        popup.dismiss();
    }

    @Step("If - else if - else")
    public static void initFeeds(String elem1){
        String elem2;
        if (elem1.equalsIgnoreCase(BitrixLike.like_approve.getText())){
            driver.equals(elem1);}
        else if (elem1.equalsIgnoreCase(BitrixLike.like_approve.getText())){
            driver.equals(BitrixLike.btn_like);}
        else
            throw new RuntimeException("Invalid Feed btn");
    }

    @Step("Switch - Iframe1")
    public static void switch_Frames(){
        WebElement ifrm = driver.findElement(By.cssSelector("iframe[class='bx-editor-iframe']"));
        driver.switchTo().frame(ifrm);
    }

    @Step("Switch - Iframe2")
    public static void switch_Frame1(){
        WebElement ifrm = driver.findElement(By.cssSelector("iframe[class='side-panel-iframe']"));
        driver.switchTo().frame(ifrm);
    }

    @Step("Go to Default iFrame")
    public static void moveOut_iFrame(){
         driver.switchTo().defaultContent();
    }

    @Step("ContextClick - Right Button on Element")
    public static void rightclick(WebElement elem1){
        action.contextClick(elem1).build().perform();
    }

    @Step("Insert Key")
    public static void insertKey(WebElement elem, Keys value){
        elem.sendKeys(value);
    }

}
